/* 
 * File:   main.cpp
 * Author: Laura Herrera    
 * Purpose: Homework assignment (Gaddis_7thEd_Ch2_Problem 1)
 *
 * Created on January 11, 2015, 2:18 AM
 */
//System Libraries
#include <iostream>

using namespace std;
//User Libraries
//Global Constants
//Function Prototypes
/*
 //Execution begins here
 */
int main() 
{
 //Declare variables
 int num1 = 62;
 int num2 = 99;
 int total = num1+num2;
 
 //Calculate num1 + num2
 
 cout<<"62+99 = "<<total<<endl;
 //Exit stage right! 
    return 0;
}

